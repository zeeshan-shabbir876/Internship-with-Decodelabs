# Project 2: Data Classification Using AI

**DecodeLabs - Artificial Intelligence Industrial Training Kit (Batch 2026)**

A supervised-learning pipeline that classifies iris flowers into three species
(*setosa*, *versicolor*, *virginica*) with the **K-Nearest Neighbors** algorithm.

## Pipeline (IPO framework)

| Stage | What happens |
|-------|--------------|
| **Input** | Load the Iris dataset (150 samples, 4 features, 3 balanced classes), inspect it, scale features with `StandardScaler` |
| **Process** | Shuffled + stratified 80/20 train-test split, choose K with cross-validation, train KNN |
| **Output** | Accuracy, confusion matrix, precision / recall / F1 score |

## Key design decisions

- **No data leakage:** scaling lives inside a scikit-learn `Pipeline`, so the scaler
  only learns from training data.
- **Test set stays locked:** K is tuned with 5-fold cross-validation on the training
  set only. The test set is used once, for the final evaluation.
- **Shuffle + stratify:** removes order bias and keeps class proportions equal in
  both splits.
- **Beyond accuracy:** the confusion matrix and F1 score are reported because
  accuracy alone can mislead on imbalanced data.
- **Reproducible:** fixed random seed (`42` by default).

## Setup

```bash
git clone <your-repo-url>
cd iris-knn-classifier
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
python iris_classification.py
```

Optional arguments:

| Flag | Default | Description |
|------|---------|-------------|
| `--test-size` | `0.2` | Fraction of data held out for testing |
| `--max-k` | `30` | Largest K tried during tuning |
| `--seed` | `42` | Random seed |
| `--output-dir` | `outputs` | Where plots and metrics are saved |

## Output

Results are written to `outputs/`:

- `01_data_overview.png` - feature scatter plots by species
- `02_k_selection.png` - cross-validated error rate vs K (the "elbow" curve)
- `03_confusion_matrix.png` - test-set confusion matrix
- `metrics.txt` - accuracy, precision, recall and F1 summary

### Sample result (seed 42)

- Best K: **3** (cross-validation accuracy 96.7%)
- Test accuracy: **93.3%**, macro F1: **0.933**
- The only errors are 2 virginica flowers predicted as versicolor, which is the
  species pair that overlaps most in feature space.

## Project structure

```
iris-knn-classifier/
├── iris_classification.py
├── requirements.txt
├── README.md
├── .gitignore
└── outputs/
```

## Skills demonstrated

Data handling, supervised learning basics, feature scaling, model training,
hyperparameter tuning, and model evaluation.
