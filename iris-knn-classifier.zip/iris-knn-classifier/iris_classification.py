"""
Project 2: Data Classification Using AI
DecodeLabs - Artificial Intelligence Industrial Training Kit (Batch 2026)

Pipeline (IPO framework)
------------------------
INPUT   : Load the Iris dataset and understand it, then scale the features.
PROCESS : Shuffled, stratified 80/20 train-test split + K-Nearest Neighbors.
OUTPUT  : Accuracy, confusion matrix, precision / recall / F1 score.

Design decisions
----------------
* Scaling happens INSIDE a scikit-learn Pipeline, so the scaler is fitted on
  training data only. This prevents data leakage from the test set.
* The best "K" is chosen with 5-fold cross-validation on the TRAINING set
  only. The test set stays locked until the final evaluation.
* Everything is reproducible through a fixed random seed.

Usage
-----
    python iris_classification.py
    python iris_classification.py --test-size 0.2 --max-k 30 --seed 42
    python iris_classification.py --output-dir results
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # Headless backend: plots are saved to files.
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.datasets import load_iris  # noqa: E402
from sklearn.metrics import (  # noqa: E402
    ConfusionMatrixDisplay,
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import (  # noqa: E402
    StratifiedKFold,
    cross_val_score,
    train_test_split,
)
from sklearn.neighbors import KNeighborsClassifier  # noqa: E402
from sklearn.pipeline import Pipeline  # noqa: E402
from sklearn.preprocessing import StandardScaler  # noqa: E402

DEFAULT_SEED = 42


# --------------------------------------------------------------------------
# INPUT: load + understand data
# --------------------------------------------------------------------------
def load_data() -> tuple[pd.DataFrame, pd.Series, list[str]]:
    """Load the Iris dataset as a feature DataFrame and a label Series."""
    iris = load_iris(as_frame=True)
    X = iris.data.copy()
    X.columns = [c.replace(" (cm)", "").replace(" ", "_") for c in X.columns]
    y = iris.target.copy()
    y.name = "species"
    return X, y, [str(n) for n in iris.target_names]


def explore_data(X: pd.DataFrame, y: pd.Series, class_names: list[str]) -> None:
    """Print a quick summary so we understand the dataset before modelling."""
    print("=" * 70)
    print("STEP 1 - LOAD AND UNDERSTAND THE DATASET")
    print("=" * 70)
    print(f"Samples   : {X.shape[0]}")
    print(f"Features  : {X.shape[1]}  -> {list(X.columns)}")
    print(f"Classes   : {len(class_names)}  -> {class_names}")
    print(f"Missing   : {int(X.isna().sum().sum())} values")
    print("\nFirst 5 rows:")
    print(X.head().to_string())
    print("\nFeature statistics:")
    print(X.describe().round(2).to_string())
    print("\nClass distribution (balanced dataset expected):")
    counts = y.map(dict(enumerate(class_names))).value_counts().sort_index()
    print(counts.to_string())


def plot_data_overview(
    X: pd.DataFrame, y: pd.Series, class_names: list[str], out_path: Path
) -> None:
    """Scatter plots of the two most informative feature pairs."""
    pairs = [("sepal_length", "sepal_width"), ("petal_length", "petal_width")]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    for ax, (fx, fy) in zip(axes, pairs):
        for idx, name in enumerate(class_names):
            mask = y == idx
            ax.scatter(X.loc[mask, fx], X.loc[mask, fy], label=name, alpha=0.8,
                       edgecolor="k", linewidth=0.4)
        ax.set_xlabel(f"{fx.replace('_', ' ')} (cm)")
        ax.set_ylabel(f"{fy.replace('_', ' ')} (cm)")
        ax.grid(alpha=0.3)
    axes[0].legend(title="Species")
    fig.suptitle("Iris dataset overview")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# --------------------------------------------------------------------------
# PROCESS: model construction, tuning, training
# --------------------------------------------------------------------------
def build_pipeline(k: int) -> Pipeline:
    """Scaler + KNN. The scaler is fitted on training data only (no leakage)."""
    return Pipeline(
        steps=[
            ("scaler", StandardScaler()),  # mean = 0, variance = 1
            ("knn", KNeighborsClassifier(n_neighbors=k)),
        ]
    )


def find_best_k(
    X_train: pd.DataFrame, y_train: pd.Series, max_k: int, seed: int
) -> tuple[int, pd.DataFrame]:
    """Pick K by 5-fold cross-validated error on the TRAINING data only.

    Ties are broken in favour of the larger K (a smoother, more general model).
    """
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    rows = []
    for k in range(1, max_k + 1):
        scores = cross_val_score(build_pipeline(k), X_train, y_train, cv=cv,
                                 scoring="accuracy")
        rows.append({"k": k, "cv_accuracy": scores.mean(),
                     "cv_error": 1.0 - scores.mean()})
    results = pd.DataFrame(rows)
    min_error = results["cv_error"].min()
    best_k = int(results.loc[np.isclose(results["cv_error"], min_error), "k"].max())
    return best_k, results


def plot_k_selection(results: pd.DataFrame, best_k: int, out_path: Path) -> None:
    """Error-rate vs K curve with the chosen K highlighted."""
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.plot(results["k"], results["cv_error"], marker="o", color="#1f3b73")
    best_err = results.loc[results["k"] == best_k, "cv_error"].iloc[0]
    ax.scatter([best_k], [best_err], s=260, facecolors="none",
               edgecolors="#e8531e", linewidths=2.5, label=f"Chosen K = {best_k}")
    ax.set_xlabel("K value")
    ax.set_ylabel("Cross-validated error rate")
    ax.set_title("Tuning the engine: choosing K")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# --------------------------------------------------------------------------
# OUTPUT: evaluation
# --------------------------------------------------------------------------
def evaluate(
    y_true: pd.Series, y_pred: np.ndarray, class_names: list[str], out_path: Path
) -> dict[str, float]:
    """Print metrics, save the confusion matrix, and return summary numbers."""
    labels = list(range(len(class_names)))
    cm = confusion_matrix(y_true, y_pred, labels=labels)

    print("\n" + "=" * 70)
    print("STEP 4 - OUTPUT VALIDATION (held-out test set)")
    print("=" * 70)
    print("Confusion matrix (rows = actual, columns = predicted):")
    print(pd.DataFrame(cm, index=class_names, columns=class_names).to_string())
    print("\nClassification report:")
    print(classification_report(y_true, y_pred, labels=labels,
                                target_names=class_names, digits=3, zero_division=0))

    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_weighted": f1_score(y_true, y_pred, average="weighted", zero_division=0),
    }
    for name, value in metrics.items():
        print(f"{name:<16}: {value:.4f}")

    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay(cm, display_labels=class_names).plot(
        ax=ax, cmap="Blues", colorbar=False, values_format="d")
    ax.set_title("Confusion matrix (test set)")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return metrics


def save_metrics(metrics: dict[str, float], best_k: int, args: argparse.Namespace,
                 out_path: Path) -> None:
    """Write a small plain-text summary of the run."""
    lines = [
        "Project 2 - Iris KNN classification",
        f"random_seed : {args.seed}",
        f"test_size   : {args.test_size}",
        f"best_k      : {best_k}",
        "",
        *[f"{k:<16}: {v:.4f}" for k, v in metrics.items()],
    ]
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Iris classification with K-Nearest Neighbors.")
    parser.add_argument("--test-size", type=float, default=0.2,
                        help="Fraction of data held out for testing (default: 0.2)")
    parser.add_argument("--max-k", type=int, default=30,
                        help="Largest K to try during tuning (default: 30)")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED,
                        help=f"Random seed for reproducibility (default: {DEFAULT_SEED})")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"),
                        help="Folder for plots and metrics (default: outputs)")
    args = parser.parse_args()

    if not 0.0 < args.test_size < 1.0:
        parser.error("--test-size must be strictly between 0 and 1")
    if args.max_k < 1:
        parser.error("--max-k must be at least 1")
    return args


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    # ---- INPUT -----------------------------------------------------------
    X, y, class_names = load_data()
    explore_data(X, y, class_names)
    plot_data_overview(X, y, class_names, args.output_dir / "01_data_overview.png")

    # ---- PROCESS: split --------------------------------------------------
    print("\n" + "=" * 70)
    print("STEP 2 - TRAIN / TEST SPLIT (shuffled + stratified)")
    print("=" * 70)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=args.test_size,
        shuffle=True,          # randomize to remove order bias
        stratify=y,            # keep class proportions equal in both sets
        random_state=args.seed,
    )
    print(f"Training samples: {len(X_train)}  |  Testing samples: {len(X_test)}")
    print("Train class counts:", np.bincount(y_train).tolist())
    print("Test  class counts:", np.bincount(y_test).tolist())

    # ---- PROCESS: tune K -------------------------------------------------
    print("\n" + "=" * 70)
    print("STEP 3 - TUNE K AND TRAIN THE KNN MODEL")
    print("=" * 70)
    # Each CV fold trains on 80% of the training set, so K cannot exceed that.
    max_k = min(args.max_k, int(len(X_train) * 0.8))
    best_k, k_results = find_best_k(X_train, y_train, max_k, args.seed)
    plot_k_selection(k_results, best_k, args.output_dir / "02_k_selection.png")
    best_row = k_results.loc[k_results["k"] == best_k].iloc[0]
    print(f"Tested K = 1..{max_k} with 5-fold cross-validation on training data.")
    print(f"Best K = {best_k} (CV accuracy = {best_row['cv_accuracy']:.4f})")

    # Instantiate -> Fit -> Predict
    model = build_pipeline(best_k)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    # ---- OUTPUT ----------------------------------------------------------
    metrics = evaluate(y_test, predictions, class_names,
                       args.output_dir / "03_confusion_matrix.png")
    save_metrics(metrics, best_k, args, args.output_dir / "metrics.txt")

    # ---- Try the model on brand-new, unseen measurements -----------------
    print("\n" + "=" * 70)
    print("BONUS - PREDICT NEW, UNSEEN FLOWERS")
    print("=" * 70)
    new_flowers = pd.DataFrame(
        [[5.0, 3.4, 1.5, 0.2],    # looks like setosa
         [6.0, 2.8, 4.3, 1.3],    # looks like versicolor
         [6.9, 3.1, 5.8, 2.2]],   # looks like virginica
        columns=X.columns,
    )
    for row, pred, proba in zip(new_flowers.values, model.predict(new_flowers),
                                model.predict_proba(new_flowers)):
        print(f"{row.tolist()} -> {class_names[pred]} "
              f"(confidence {proba.max():.0%})")

    print(f"\nDone. Plots and metrics saved in: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
